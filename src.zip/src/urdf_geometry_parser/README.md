urdf_geometry_parser
===============

See [ros_control](http://wiki.ros.org/ros_control) and [urdf_geometry_parser](http://wiki.ros.org/urdf_geometry_parser) documentation on ros.org

### Build Status
[![Build Status](https://github.com/ros-controls/urdf_geometry_parser/workflows/Test%20urdf_geometry_parser/badge.svg?branch=kinetic-devel)](https://github.com/ros-controls/urdf_geometry_parser/actions?query=workflow%3A%22Test+urdf_geometry_parser%22+branch%3Akinetic-devel)
