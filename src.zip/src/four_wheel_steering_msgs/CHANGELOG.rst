^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package four_wheel_steering_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.1 (2020-05-13)
------------------
* Update maintainer email
* Contributors: Vincent Rousseau

1.1.0 (2020-04-06)
------------------
* Bump CMake version to avoid CMP0048 warning (`#4 <https://github.com/ros-drivers/four_wheel_steering_msgs/issues/4>`_)
* Contributors: Alejandro Hernández Cordero

1.0.0 (2017-04-26)
------------------
* Update url path
* Initial commit from https://github.com/Romea/romea_controllers
* Contributors: Vincent Rousseau
