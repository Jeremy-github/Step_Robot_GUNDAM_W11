^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package gundam_robot
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.4 (2020-08-28)
------------------

0.0.3 (2020-01-28)
------------------

0.0.2 (2020-01-20)
------------------
* add gundam_robot meta package (`#5 <https://github.com/gundam-global-challenge/gundam_robot/issues/5>`_)
* Contributors: Kei Okada


0.0.1 (2019-07-01)
------------------
